THANKYOU_LIST

thank you
thankyou
thanks
goodbye
good bye
nothing
much appreciated


TEMPERATURE_LIST

living
living room
livingroom
bedroom
bed room
bed
beroom

LIST_OF_SENSORS

temperature
pressure
accelerometer
humidity
gesture


LIST_OF_ACTUATORS

Coffee
brew coffee
coffee machine
brew some coffee
Stepper
Servo
Light
Fan
