sensorReadIntent {Sensor}
sensorReadIntent What does the {Sensor} sensor read
sensorReadIntent What is the current {Sensor} sensor reading
sensorReadIntent What does the {Sensor} sensor read now
sensorReadIntent What is the value of the {Sensor} sensor

pressureReadIntent What is the pressure
pressureReadIntent What is the current pressure
pressureReadIntent What is the pressure in the room
pressureReadIntent What is the current pressure in the room

humidityReadIntent What is the humidity in the room
humidityReadIntent How humid is it in the room
humidityReadIntent How humid is it in here
humidityReadIntent Whats the humidity
humidityReadIntent What is the humidity

temperatureReadIntent What is the current temperature in {Temperature}
temperatureReadIntent What is the current temperature in the {Temperature} room
temperatureReadIntent Whats the temperature in the {Temperature} room
temperatureReadIntent Whats the {Temperature} temperature
temperatureReadIntent How hot is it in {Temperature}
temperatureReadIntent How hot is it in the {Temperature} room
temperatureReadIntent How hot is it in {Temperature} room
temperatureReadIntent How cold is it in {Temperature} room
temperatureReadIntent How cold is it {Temperature} room
temperatureReadIntent How cold is it in {Temperature} room
temperatureReadIntent How much is the temperature in {Temperature} room

thankyouIntent {Thankyou}
thankyouIntent Thank you so much for your help
thankyouIntent Nothing
thankyouIntent Goodbye

yesIntent Yes please
yesIntent yes
yesIntent yeah
yesIntent yea sure
yesIntent yeah ofcourse
yesIntent yes ofcourse
yesIntent ofcourse please
yesIntent please
yesIntent yeah go ahead
yesIntent please go ahead

noIntent no
noIntent i gotto go
noIntent sorry no
noIntent na
noIntent nope
noIntent no i have to go
noIntent no i gotto go
noIntent i have to go
noIntent sorry

actuateIntent actuate {Actuate}
actuateIntent Brew coffee
actuateIntent turn on {Actuate}

repeatIntent Sorry I missed it
repeatIntent Sorry can you repeat it
repeatIntent Can you repeat it please
repeatIntent Can you repeat it for me please
